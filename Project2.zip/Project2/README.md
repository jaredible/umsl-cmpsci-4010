# Mindbank
[View the syllabus](http://htmlpreview.github.io/?https://github.com/jaredible/umsl-cmpsci-4010/blob/master/Project2/CS4010Fall2019Project2.html)
<br/>

### Prerequisites

* JDK
* Tomcat
* XAMPP

### Install

- Execute the file, init.sql, within the directory, src, on phpMyAdmin.

### Deployment

- Run this project on Tomcat.
