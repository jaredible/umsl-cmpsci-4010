package main.java.mindbank.util;

import java.util.ArrayList;

import main.java.mindbank.model.Problem;

public class ProblemList extends ArrayList<Problem> {

	private static final long serialVersionUID = -2847437087048509560L;

}
