package main.java.mindbank.util;

import java.util.ArrayList;

import main.java.mindbank.model.Category;

public class CategoryList extends ArrayList<Category> {

	private static final long serialVersionUID = 6516699156564346588L;

}
