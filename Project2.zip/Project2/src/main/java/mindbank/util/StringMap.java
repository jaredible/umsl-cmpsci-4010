package main.java.mindbank.util;

import java.util.HashMap;

public class StringMap extends HashMap<String, String> {

	private static final long serialVersionUID = -4290371869909284390L;

}
