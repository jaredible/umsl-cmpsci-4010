package main.java.mindbank.util;

import java.util.ArrayList;

import main.java.mindbank.model.ProblemInfo;

public class ProblemInfoList extends ArrayList<ProblemInfo> {

	private static final long serialVersionUID = -4830427511363549296L;

}
